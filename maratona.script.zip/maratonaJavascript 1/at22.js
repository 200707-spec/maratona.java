// Solicita o nome completo ao usuário
let nomeCompleto = prompt("Digite seu nome completo:");

// Exibe o primeiro nome
let primeiroNome = nomeCompleto.split(' ')[0];
console.log("Seu primeiro nome é: " + primeiroNome);

