// Solicita o nome ao usuário
let nome = prompt("Digite seu nome:");

// Verifica se o nome começa com "A"
if (nome.charAt(0).toUpperCase() === 'A') {
  console.log("O nome começa com a letra A.");
} else {
   console.log("O nome não começa com a letra A.");
}

