let num1 = parseInt(prompt("Digite o primeiro número:"));
let num2 = parseInt(prompt("Digite o segundo número:"));

if (num1 % num2 === 0) {
    console.log(num1 + " é divisível por " + num2);
} else {
    console.log(num1 + " não é divisível por " + num2);
}


