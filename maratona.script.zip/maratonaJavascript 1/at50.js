let numero = parseInt(prompt("Digite um número para ver a sua tabuada:"));

for (let i = 1; i <= 10; i++) {
    console.log(numero + " x " + i + " = " + (numero * i));
}



