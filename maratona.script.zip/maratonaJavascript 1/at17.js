// Solicita uma palavra ao usuário
let palavra = prompt("Digite uma palavra:");

// Exibe cada letra separadamente
for (let i = 0; i < palavra.length; i++) {
    console.log(palavra[i]);
}

