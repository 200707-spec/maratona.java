// Solicita duas palavras ao usuário
let palavra1 = prompt("Digite a primeira palavra:");
let palavra2 = prompt("Digite a segunda palavra:");

// Concatena as palavras
let palavraConcatenada = palavra1 + " " + palavra2;

// Exibe o resultado
console.log("A palavra concatenada é: " + palavraConcatenada);

