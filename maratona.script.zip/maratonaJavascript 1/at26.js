// Solicita a idade ao usuário
let idade = parseInt(prompt("Digite sua idade:"));

// Verifica se é maior de idade
if (idade >= 18) {
    console.log("Você é maior de idade.");
} else {
    console.log("Você é menor de idade.");
}


