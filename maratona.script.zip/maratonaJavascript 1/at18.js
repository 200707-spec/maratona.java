
// Solicita a frase ao usuário
let frase = prompt("Digite uma frase:");

// Substitui todas as ocorrências de 'a' por 'e'
let novaFrase = frase.replace(/a/g, 'e');

// Exibe o resultado
console.log("A nova frase é: " + novaFrase);

