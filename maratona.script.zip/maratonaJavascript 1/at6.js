// Solicita o raio ao usuário
let raio = parseFloat(prompt("Digite o raio do círculo (em metros):"));

// Calcula o perímetro
let perimetro = 2 * Math.PI * raio;

// Exibe o resultado
console.log("O perímetro do círculo é: " + perimetro.toFixed(2));

