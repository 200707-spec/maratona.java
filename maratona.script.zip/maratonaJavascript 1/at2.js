
let numero1 = parseFloat(prompt("Digite o primeiro número:"));
let numero2 = parseFloat(prompt("Digite o segundo número:"));

// Calcula a média aritmética
let media = (numero1 + numero2) / 2;

// Exibe o resultado
console.log("A média aritmética é: " + media);


