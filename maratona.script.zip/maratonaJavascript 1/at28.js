let n1 = parseFloat(prompt("Digite o primeiro número:"));//indica para o usuario digitar o primeiro número//
let n2 = parseFloat(prompt("Digite o segundo número:"));//indica para o usuario digitar o segundo número//
let n3 = parseFloat(prompt("Digite o terceiro número:"));//indica para o usuario digitar o terceiro número//


let maior = Math.max(n1, n2, n3);

console.log("O maior número é: " + maior);



