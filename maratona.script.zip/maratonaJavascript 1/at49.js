
// Números pares de 1 a 50
for (let i = 2; i <= 50; i += 2) {
    console.log(i);
}

// Números ímpares de 51 a 100
for (let i = 51; i <= 100; i += 2) {
    console.log(i);
}

