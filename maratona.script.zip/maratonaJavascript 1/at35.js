let n1 = parseFloat(prompt("Digite o primeiro número:"));
let n2 = parseFloat(prompt("Digite o segundo número:"));
let n3 = parseFloat(prompt("Digite o terceiro número:"));

let maior = Math.max(n1, n2, n3);
let menor = Math.min(n1, n2, n3);

console.log("Maior número: " + maior + "\nMenor número: " + menor);

