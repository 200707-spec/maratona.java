let nota1 = parseFloat(prompt("Digite a nota da primeira prova:"));
let nota2 = parseFloat(prompt("Digite a nota da segunda prova:"));

console.log("Prova 1: " + (nota1 >= 6 ? "Aprovado" : "Reprovado"));
console.log("prova2:" + (nota2 >= 6 ? "Aprovado" : "Reprovado"));   



