// Solicita o raio ao usuário
let raio = parseFloat(prompt("Digite o raio do círculo (em metros):"));

// Calcula a área
let area = Math.PI * (raio * raio);

// Exibe o resultado
console.log("A área do círculo é: " + area.toFixed(2));

